Zevex Gateway - Android app (WebView + BharatPe login helper)

Panel ka address badalna ho to: app/build.gradle.kts me BASE_URL.
Package: com.zevex.gateway

APK GitHub Actions se banta hai (repo me zevex-app.zip + .github/workflows/build.yml).
Build ke baad Actions -> latest run -> Artifacts -> zevex-apk.
