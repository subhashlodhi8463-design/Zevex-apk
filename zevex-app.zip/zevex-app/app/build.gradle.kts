plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.zevex.gateway"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.zevex.gateway"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        // Panel ka address: sirf yahin badalna hai
        buildConfigField("String", "BASE_URL", "\"https://zevex.in/auth/\"")
    }

    buildFeatures { buildConfig = true }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
}
